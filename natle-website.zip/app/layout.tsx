import type { Metadata } from "next";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: "NATLE — Precision Agriculture Software, with Hosma Ceylon",
  description:
    "NATLE builds FieldOS, YieldAI and TraceLink in strategic partnership with Hosma Ceylon — IoT telemetry, harvest forecasting and export compliance for coconut, tea and hydroponic estates.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="font-body antialiased">
        <div className="relative z-10">
          <Header />
          <main>{children}</main>
          <Footer />
        </div>
      </body>
    </html>
  );
}
